//
//  ViewController.h
//  KKwebConfig
//
//  Created by apple on 2019/1/20.
//  Copyright © 2019 KK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

